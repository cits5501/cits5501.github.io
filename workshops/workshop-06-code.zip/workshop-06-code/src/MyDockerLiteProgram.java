
import java.util.ArrayList;
import java.util.Arrays;

public class MyDockerLiteProgram {
  
  static final class Options {
    final boolean isVerbose;
    final String subCommand;
    final String image;
    
    public Options(boolean isVerbose, String subCommand, String image) {
      this.isVerbose = isVerbose;
      this.subCommand = subCommand;
      this.image = image;
    }

    @Override
    public String toString() {
      return "Options [isVerbose=" + isVerbose + ", subCommand=" + subCommand
              + ", image=" + image + "]";
    }
  }
  
  Options options;
  
  public static Options parseArgs(ArrayList<String> args) {
    
    // process optional arg
    boolean verbosity = false;
    if (args.get(0).equals("--verbose")) {
      verbosity = true;
      args.remove(0);
    }
    
    // process subcommand
    String subCommand;
    if (   args.get(0).equals("pull")
        || args.get(0).equals("run")
        || args.get(0).equals("build") ) 
    {
      subCommand = args.get(0);
      args.remove(0);
    } else {
      throw new IllegalArgumentException("invalid subcommand");
    }
    
    // process image
    String image;
    if (   args.get(0).equals("debian")
        || args.get(0).equals("ubuntu")
        || args.get(0).equals("fedora") ) 
    {
      image = args.get(0);
      args.remove(0);
    } else {
      throw new IllegalArgumentException("invalid image");
    }
    
    // if any args remain, that's incorrect
    if (args.size() > 0) {
      throw new IllegalArgumentException("invalid arguments following image");
    }
    
    return new Options(verbosity, subCommand, image);
  }

  public static void main(String args[]) {
    Options options = parseArgs(new ArrayList<String>(Arrays.asList(args)) );
    System.out.println("options were: " + options);
    // now do something with the options ...
  }

}
