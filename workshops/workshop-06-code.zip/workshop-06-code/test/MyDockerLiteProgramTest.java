import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;


class MyDockerLiteProgramTest {

  /**
   * Test method for {@link MyDockerLiteProgram#parseArgs(java.util.List)}.
   */
  @Test
  void validArgumentsParseOk() {
    String args[] = { "--verbose", "pull", "debian" };
    MyDockerLiteProgram.Options options = MyDockerLiteProgram.parseArgs( 
        new ArrayList<String>(Arrays.asList(args))
    );
    assertEquals(true, options.isVerbose, "verboseness should be true");
    assertEquals("pull", options.subCommand);
    assertEquals("debian", options.image);
  }

}
