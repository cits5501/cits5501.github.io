
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.quicktheories.QuickTheory.qt;
import static org.quicktheories.generators.SourceDSL.*;

public class PropTest02IntSum {

  /** For any two positive integers,
   * /i/ and /j/, it's always true that
   * i + j > 0.
   */
  @Test
  public void sumOfTwoPositivesIsPositive(){
    qt()
    .forAll(integers().allPositive()
          , integers().allPositive())
        .check((i,j) -> i + j > 0); 
  }

}
