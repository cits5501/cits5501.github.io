
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.quicktheories.QuickTheory.qt;
import static org.quicktheories.generators.SourceDSL.*;

public class PropTest03StringReverse {

  public static String reverse(String s) {
    return new StringBuilder(s).reverse().toString();
  }

  /** For any string /s/, if we reverse it, and then
   * reverse it again, we should end up with the same string.
   */
  @Test
  public void reverseTwiceIsIdentity(){
    qt()
    .forAll(strings().basicLatinAlphabet().ofLengthBetween(0, 10)
          )
    .check((s) -> reverse( reverse(s) ).equals(s) );

  }

}
