
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.quicktheories.QuickTheory.qt;
import static org.quicktheories.generators.SourceDSL.*;

public class PropTest04SpaceCollapse {

  /**
  * Remove/collapse multiple spaces.
  *
  * @param String string to remove multiple spaces from.
  * @return String
  */
  public static String collapseSpaces(String argStr) {
    if (argStr.length() == 0) {
      return argStr;
    }

    char last = argStr.charAt(0);
    StringBuffer argBuf = new StringBuffer();
    
    for (int cIdx = 0 ; cIdx < argStr.length(); cIdx++) {
      char ch = argStr.charAt(cIdx);
      if (ch != ' ' || last != ' ') {
        argBuf.append(ch);
        last = ch;
      }
    }
    return argBuf.toString();
  }

  public static String reverse(String s) {
    return new StringBuilder(s).reverse().toString();
  }

  /** For any string /s/, if we reverse it, and then
   * reverse it again, we should end up with the same string.
   */
  @Test
  public void collapsedIsShorter(){
    qt()
    .forAll(strings().basicLatinAlphabet().ofLengthBetween(0, 10)
          )
    .check((s) -> {
        String res = collapseSpaces(s);
        return res.length() <= s.length();
     });

  }

}
