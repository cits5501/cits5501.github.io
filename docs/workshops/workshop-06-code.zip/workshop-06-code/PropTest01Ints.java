
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.quicktheories.QuickTheory.qt;
import static org.quicktheories.generators.SourceDSL.*;

public class PropTest01Ints {

  /** For any positive integer /i/, it's
   * always true that i == i.
   */
  @Test
  public void integerAlwaysEqualsItself(){
    qt()
    .forAll(integers().allPositive())
    .check((i) -> i == i);
  }

}
