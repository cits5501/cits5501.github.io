
/**
 * Base class for responses that can be received from GLADIUS
 * remote servers.
 */
abstract public class CommandResponse {

}
