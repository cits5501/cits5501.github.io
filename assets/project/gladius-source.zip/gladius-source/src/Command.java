
/**
 * Base class for commands that can be sent to GLADIUS
 * remote servers.
 */
abstract public class Command {

}
