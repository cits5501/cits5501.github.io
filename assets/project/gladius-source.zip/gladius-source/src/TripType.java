
public enum TripType {
  ONE_WAY, RETURN
}
