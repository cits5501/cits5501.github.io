import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class SegmentSubcommandTest {

  /**
   * Stub test method for {@link SegmentSubcommand#SegmentSubcommand(java.lang.String, java.lang.String, java.lang.String, java.time.LocalDate, CabinType, int)}.
   */
  @Test
  void testSegmentSubcommand() {
    fail("Not yet implemented"); // TODO
  }

}
