import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CommandParserTest {


  /**
   * Stub test method for {@link CommandParser#parse(java.lang.String[])}.
   */
  @Test
  final void testParse() {
    fail("Not yet implemented"); // TODO
  }

}
