package processors;

import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import core.Chunk;
import parsers.Parser;
import utilities.MemIO;
import utilities.StringUtilities;

/** Test the processors.ShellProcessor class
 *
 */
class ShellProcessorTest {

  
  @Test
  public void testOneLineDoc() throws ExecutionException {
    String inputText = "some text";
    BufferedReader reader = StringUtilities.stringToBufferedReader(inputText);
    Parser parser = new Parser(reader);
    parser.parse();
    List<Chunk> chunks = parser.getChunks();

    MemIO mio = new MemIO();
    Processor processor = new ShellProcessor(mio.out, chunks);
    processor.merge();

    String actual = mio.getContents();
    //String expected = /* string goes here */;
    // assertEquals(expected, actual, "actual text should equal expected");
  }

}
