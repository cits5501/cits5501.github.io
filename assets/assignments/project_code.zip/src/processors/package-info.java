/** Classes that process a list of chunks into an output document.
 */
package processors;
