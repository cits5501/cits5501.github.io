
/**
 * The JDocGen app.
 */
package app;