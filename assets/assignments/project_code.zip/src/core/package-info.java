/**
 * Classes that represent a chunk of document text.
 */

package core;