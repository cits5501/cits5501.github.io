/** Utility classes.
 */
package utilities;
